## WordPress CRUD Application Plugin

This Is A Plugin For WordPress CRUD ( Create, Read, Update & Delete ) Application Using Ajax & WP List Table
