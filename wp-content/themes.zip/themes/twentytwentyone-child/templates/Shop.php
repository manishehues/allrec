<?php

/**
 * Template Name: Shop Page
 *
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();
?>


<div class="container">
  <div class="ticket_tittle">
    <div class="tittle">
      <div class="content">
        <h1><span>EVENTS</span></h1>
        <p>Come join us at these events and have some fun!</p>
      </div>
    </div>
</div>
  <?php
  get_footer();
